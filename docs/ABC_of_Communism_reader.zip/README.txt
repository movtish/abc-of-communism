The ABC of Communism
Mark Kreshchuk

Paper.pdf includes the online appendix. The two notes describe data construction, inference and additional results. Sources.md and Codebook.md document the inputs.

Data and code
https://github.com/movtish/abc-of-communism
