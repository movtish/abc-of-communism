The ABC of Communism
Mark Kreshchuk

Paper.pdf includes the online appendix. The two notes describe data construction, inference and supplementary evidence. Sources.md and Codebook.md document the inputs.

Data, code and archived source documents
https://github.com/movtish/abc-of-communism

This reading package excludes the raw source archive.
